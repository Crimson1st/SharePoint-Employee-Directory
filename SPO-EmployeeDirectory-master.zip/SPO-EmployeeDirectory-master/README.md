This SharePoint Online Employee Directory repository accomapanies the white paper on "Building your own Office 365 Employee Directory".

The purpose of these SharePoint search display templates and cascading style sheets is to help you get a more advanced experience in your Office 365 environment.

